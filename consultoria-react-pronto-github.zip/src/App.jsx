import React from "react";
import Site from "./Site.jsx";

export default function App() {
  return <Site />;
}
