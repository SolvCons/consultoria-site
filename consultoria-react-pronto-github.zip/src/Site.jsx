import React from "react";

export default function Site() {
  return (
    <div className="p-10 text-center">
      <h1 className="text-4xl font-bold">Site de Consultoria</h1>
      <p className="mt-4 text-lg">Substitua este arquivo pelo código completo do seu site.</p>
    </div>
  );
}
